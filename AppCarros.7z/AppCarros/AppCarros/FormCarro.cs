﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCarros
{
    public partial class FormCarro : Form
    {
        public FormCarro()
        {
            InitializeComponent();
        }

        private void FormCarro_Load(object sender, EventArgs e)
        {
            Carro car = new Carro();
            List<Carro> carros = car.listacarro();
            dgvCarro.DataSource = carros;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Carro carro = new Carro();
                carro.Inserir(txtMarca.Text, txtModelo.Text, txtKm.Text, txtQuantidade.Text, dtpDtCadastro.Value, txtDescricao.Text, txtClassificacao.Text, txtEstado.Text, txtPreco.Text);
                MessageBox.Show("Veículo cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Carro> car = carro.listacarro();
                dgvCarro.DataSource = car;
                txtMarca.Text = "";
                txtModelo.Text = "";
                txtKm.Text = "";
                txtQuantidade.Text = "";
                this.dtpDtCadastro.Value = DateTime.Now.Date;
                txtDescricao.Text = "";
                txtClassificacao.Text = "";
                txtEstado.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Carro carro = new Carro();
                carro.Localiza(id);
                txtMarca.Text = carro.Marca;
                txtModelo.Text = carro.Modelo;
                txtKm.Text = carro.Km;
                txtQuantidade.Text = carro.Quantidade;
                dtpDtCadastro.Value = Convert.ToDateTime(carro.Cadastro);
                txtDescricao.Text = carro.Descrição;
                txtClassificacao.Text = carro.Classificação;
                txtEstado.Text = carro.Estado;
                txtPreco.Text = carro.Preço;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Carro carro = new Carro();
                carro.Atualizar(id, txtMarca.Text, txtModelo.Text, txtKm.Text, txtQuantidade.Text, dtpDtCadastro.Value, txtDescricao.Text, txtClassificacao.Text, txtEstado.Text, txtPreco.Text);
                MessageBox.Show("Veículo atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Carro> car = carro.listacarro();
                dgvCarro.DataSource = car;
                txtId.Text = "";
                txtMarca.Text = "";
                txtModelo.Text = "";
                txtKm.Text = "";
                txtQuantidade.Text = "";
                this.dtpDtCadastro.Value = DateTime.Now.Date;
                txtDescricao.Text = "";
                txtClassificacao.Text = "";
                txtEstado.Text = "";
                txtPreco.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Carro carro = new Carro();
                carro.Exclui(id);
                MessageBox.Show("Veículo excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Carro> car = carro.listacarro();
                dgvCarro.DataSource = car;
                txtId.Text = "";
                txtMarca.Text = "";
                txtModelo.Text = "";
                txtKm.Text = "";
                txtQuantidade.Text = "";
                this.dtpDtCadastro.Value = DateTime.Now.Date;
                txtDescricao.Text = "";
                txtClassificacao.Text = "";
                txtEstado.Text = "";
                txtPreco.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLimpaCampos_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtMarca.Text = "";
            txtModelo.Text = "";
            txtKm.Text = "";
            txtQuantidade.Text = "";
            this.dtpDtCadastro.Value = DateTime.Now.Date;
            txtDescricao.Text = "";
            txtClassificacao.Text = "";
            txtEstado.Text = "";
            txtPreco.Text = "";
        }

        private void dgvCarro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvCarro.Rows[e.RowIndex];
                txtId.Text = row.Cells[0].Value.ToString();
                txtMarca.Text = row.Cells[1].Value.ToString();
                txtModelo.Text = row.Cells[2].Value.ToString();
                txtKm.Text = row.Cells[3].Value.ToString();
                txtQuantidade.Text = row.Cells[4].Value.ToString();
                dtpDtCadastro.Text = row.Cells[5].Value.ToString();
                txtDescricao.Text = row.Cells[6].Value.ToString();
                txtClassificacao.Text = row.Cells[7].Value.ToString();
                txtEstado.Text = row.Cells[8].Value.ToString();
                txtPreco.Text = row.Cells[9].Value.ToString();
            }
        }
    }
}
