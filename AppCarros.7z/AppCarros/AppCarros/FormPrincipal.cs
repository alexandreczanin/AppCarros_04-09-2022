﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace AppCarros
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
            MenuVertical.Width = 90;
            pbxLogo.Visible = false;
        }
        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (MenuVertical.Width == 250)
            {
                MenuVertical.Width = 90;
                pbxLogo.Visible = false;
            }
            else
            {
                MenuVertical.Width = 250;
                pbxLogo.Visible = true;
            }
        }

        private void fechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void maximizar_Click(object sender, EventArgs e)
        {
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
            this.WindowState = FormWindowState.Maximized;
            restaurar.Visible = true;
            maximizar.Visible = false;
        }

        private void restaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            restaurar.Visible = false;
            maximizar.Visible = true;
        }

        private void minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void BarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        private void AbrirFormNoPainel(object FormDentro)
        {
            if (this.PainelDeConteudo.Controls.Count > 0)
                this.PainelDeConteudo.Controls.RemoveAt(0);
            Form fh = FormDentro as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.PainelDeConteudo.Controls.Add(fh);
            this.PainelDeConteudo.Tag = fh;
            fh.Show();
        }

        private void btnCarro_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new FormCarro());
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new FormCliente());
        }

        private void btnFuncionario_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new FormFuncionario());
        }

        private void btnContrato_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new FormContrato());
        }

        private void btnChecklist_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new FormCheckList());
        }

        private void btnAluguel_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new FormAluguel());
        }
    }
}